﻿using System;
using System.Collections.Generic;

#nullable disable

namespace GraphQl.DATA.API.Models
{
    public partial class OrderStatus
    {
        public short Id { get; set; }
        public string Status { get; set; }
    }
}
