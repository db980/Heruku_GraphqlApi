﻿using System;
using System.Collections.Generic;

#nullable disable

namespace GraphQl.DATA.API.PO.Model
{
    public partial class Automumber
    {
        public int? ExpenseId { get; set; }
    }
}
