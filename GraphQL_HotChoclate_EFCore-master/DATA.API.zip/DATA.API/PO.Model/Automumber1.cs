﻿using System;
using System.Collections.Generic;

#nullable disable

namespace GraphQl.DATA.API.PO.Model
{
    public partial class Automumber1
    {
        public int? ExpenseId { get; set; }
    }
}
