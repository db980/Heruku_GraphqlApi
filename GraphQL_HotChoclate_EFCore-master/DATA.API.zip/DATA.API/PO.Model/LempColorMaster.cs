﻿using System;
using System.Collections.Generic;

#nullable disable

namespace GraphQl.DATA.API.PO.Model
{
    public partial class LempColorMaster
    {
        public string UserCode { get; set; }
        public string Color { get; set; }
    }
}
